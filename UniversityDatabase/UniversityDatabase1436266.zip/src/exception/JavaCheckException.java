package exception;

public class JavaCheckException extends Exception 
{
	public JavaCheckException(String message)
	{
		super(message);
	}
}